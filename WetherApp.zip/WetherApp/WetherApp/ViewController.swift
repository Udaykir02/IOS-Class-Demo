//
//  ViewController.swift
//  WetherApp
//
//  Created by Singamala,Uday on 1/30/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
 
    @IBAction func BtnClicked(_ sender: Any) {
        //read input temp
        let inpText = Int(inputOL.text!)
        
        if inpText! >= 60 {
            outputOL.text = "It is Hot 🔥"
            imageOL.image = UIImage(named: "hot.jpg")
        }
        else{
            outputOL.text  = "It is Cold ❄️"
            imageOL.image = UIImage(named: "cold.webp")
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

