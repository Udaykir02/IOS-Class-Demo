//
//  ViewController.swift
//  VowelTester
//
//  Created by Singamala,Uday on 1/25/24.
//

import UIKit

class ViewController: UIViewController {
    //Taking input
    @IBOutlet weak var InputOL: UITextField!
    
    //Output Variable
    @IBOutlet weak var outputOL: UILabel!
    //
    //Function to check the temperatures
    @IBAction func checkButtonClicked(_ sender: Any) {
        var temp = Int(InputOL.text!)
        //if loop to check the temp and print message accordingly.
        if(temp! >= 60){
            outputOL.text = "It is hot outside!!"
        }
        else{
            outputOL.text = "It is Cold"
        }
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

