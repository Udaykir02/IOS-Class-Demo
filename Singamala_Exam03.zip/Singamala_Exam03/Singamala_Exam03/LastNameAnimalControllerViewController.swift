//
//  SingamalaAnimalControllerViewController.swift
//  Singamala_Exam03
//
//  Created by Uday on 4/18/24.
//

import UIKit

class LastNameAnimalControllerViewController: UIViewController {

    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    @IBOutlet weak var descriptionOL: UILabel!
    
    var image1 : UIImage!
    var name = ""
    var descriptionText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imageViewOL.image = image1
        nameOL.text = name
        descriptionOL.text = descriptionText
        self.title = name
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
