//
//  ViewController.swift
//  Singamala_Exam03
//
//  Created by Uday on 4/18/24.
//

import UIKit

class lastNameHomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = SingamalaTVOL.dequeueReusableCell(withIdentifier: "SingamalaNameCell", for: indexPath)
        cell.textLabel?.text = animal[indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "SingamalaDescriptionSegue", sender: indexPath.row)
    }

    
    @IBOutlet weak var SingamalaTVOL: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        SingamalaTVOL.delegate = self
        SingamalaTVOL.dataSource = self
        self.title = "Animals"
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "SingamalaDescriptionSegue",let selectedIndex = sender as? Int{
            let destination = segue.destination as! LastNameAnimalControllerViewController
            destination.name = animals[(SingamalaTVOL.indexPathForSelectedRow?.row)!].name!
            destination.descriptionText = animals[(SingamalaTVOL.indexPathForSelectedRow?.row)!].information!
            destination.image1 = animals[(SingamalaTVOL.indexPathForSelectedRow?.row)!].imageName
                    }
    }

}

