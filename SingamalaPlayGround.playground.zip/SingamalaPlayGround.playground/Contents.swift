import UIKit

print("Hello ALl,\rWelcome to Swift Programming🤞")

print("""
Hello
World!
""")

var age  = 30
print("You are \(age) years old and in another \(age) years, you will be \(age*2)")

var Programminglang = "Python"
 
//String interpolation
print("My favorite programming language is \(Programminglang)")


print("Hello",10.3,899)

//constant demo
let welcomemsg : String = "Hi All"
print("Welcome msg is :\(welcomemsg)")

print("Welcome  to Summer 2023")
print("************")
print("Welcome to Swift Programming language", terminator: "-")
print("Summer 2023")

print("The list of numbers are :")
print(1,2,3,4,5)

print("The list of numbers sperated by hypen are :")
print(1,2,3,4,5, separator: "-")

var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)


let pi = 3.14
print(pi)
//changing the value of constant
//pi = 4.32
//print(pi)

var age1 : Int = 23
age1 = age1 * 2
print(age1)

var message = "This is superb..!"
print(message)
print("message")


var httpError = (errorcode : 404 , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorcode, terminator: ":")
print(httpError.errorMessage)

var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName, terminator: ",")
print(lName)


