//
//  ViewController.swift
//  Singamala_Exam02
//
//  Created by Uday on 4/11/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var patientIdOL: UITextField!
    
    @IBOutlet weak var sysOL: UITextField!
    
    @IBOutlet weak var diaOL: UITextField!
    
    @IBOutlet weak var checkBtnOL: UIButton!
    
    @IBAction func patientAction(_ sender: Any) {
        updateButton()
    }
    
    @IBAction func sysAction(_ sender: Any) {
        updateButton()
    }
    
    @IBAction func diaAction(_ sender: Any) {
        updateButton()
    }
    
    
    var patientId = ""
    var bloodPressure = ""
    var Mbp = ""
    var result = ""
    var tip = ""
    var image = ""
    
    //MBP = (0.667 * diastolic) + (0.334 * systolic)
    var diastolic: Int = 0
    var systolic: Int = 0
    var MBP : Double = 0.0

    @IBAction func checkBtn(_ sender: Any) {
        diastolic = Int(diaOL.text!)!
        systolic = Int(sysOL.text!)!
        
        MBP = 0.667 * Double(diastolic) + (0.334 * Double(systolic))
        
        if(MBP < 60){
            image = "stroke"
            patientId = patientIdOL.text!
            bloodPressure = "\(diaOL.text)/\(sysOL.text ?? "0") mm Hg"
            Mbp = String(MBP)
            result = "Stroke or Internal Bleeding"
            tip = "Seek immediate medical Attention. 👨🏻‍⚕️"
        }
        else if(MBP >= 60 && MBP <= 69){
            image = "hypotension"
            patientId = patientIdOL.text!
            bloodPressure = "\(diaOL.text)/\(sysOL.text ?? "0") mm Hg"
            Mbp = String(MBP)
            result = "Hypotension"
            tip = "Stay Hydrated 🥛"
        }
        else if(MBP >= 70 && MBP <= 99){
            image = "healthy"
            patientId = patientIdOL.text!
            bloodPressure = "\(diaOL.text)/\(sysOL.text ?? "0") mm Hg"
            Mbp = String(MBP)
            result = "Healthy"
            tip = "You are doing great 👍"
        }
        else if(MBP >= 100 && MBP <= 106){
            image = "elevated"
            patientId = patientIdOL.text!
            bloodPressure = "\(diaOL.text)/\(sysOL.text ?? "0") mm Hg"
            Mbp = String(MBP)
            result = "Elevated"
            tip = "Make sure to maintain workout 🏋️"
        }
        else{
            image = "hypertension"
            patientId = patientIdOL.text!
            bloodPressure = "\(diaOL.text)/\(sysOL.text ?? "0") mm Hg"
            Mbp = String(MBP)
            result = "Hypertension"
            tip = "Consult doctor for medication tab 💊"
        }
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //checkBtnOL.isEnabled = false
    }

    func updateButton(){
        //checkBtnOL.isEnabled = (patientIdOL.text?.isEmpty == false) && (sysOL.text?.isEmpty == false) && (diaOL.text?.isEmpty == false)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "resultSegue"{
            let destination = segue.destination as! ResultViewController
            destination.image = image
            destination.Mbp = Mbp
            destination.bloodPressure = bloodPressure
            destination.patientId = patientId
            destination.result = result
            destination.tip = tip
        }
    }
}

