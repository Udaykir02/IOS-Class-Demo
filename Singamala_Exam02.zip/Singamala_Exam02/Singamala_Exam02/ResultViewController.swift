//
//  ResultViewController.swift
//  Singamala_Exam02
//
//  Created by Uday on 4/11/24.
//

import UIKit

class ResultViewController: UIViewController {
    var image = ""
    var patientId = ""
    var bloodPressure = ""
    var Mbp = ""
    var result = ""
    var tip = ""

    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var patientOut: UILabel!
    
    @IBOutlet weak var bloodOL: UILabel!
    
    @IBOutlet weak var mbpOut: UILabel!
    
    @IBOutlet weak var resultOut: UILabel!
    
    @IBOutlet weak var tipOut: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageView.image = UIImage(named: image)
        patientOut.text = "Patient Id : \(patientId)"
        bloodOL.text = "Blood Pressure : \(bloodPressure)"
        mbpOut.text = "MBP : \(Mbp)"
        resultOut.text = "Result : \(result)"
        tipOut.text = "Health Tip : \(tip)"
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
