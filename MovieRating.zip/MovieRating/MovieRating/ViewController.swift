//
//  ViewController.swift
//  MovieRating
//
//  Created by Singamala,Uday on 1/30/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    @IBAction func btnClicked(_ sender: Any) {
        let goodMovies = [" Cleo From 5 to 7 (1962)","ebel Without a Cause (1955)","The Texas Chain Saw Massacre (1974)","Throne of Blood (1957)"]
        
        let badMovies = ["Alone in the Dark","Catwoman","Battlefield Earth"]
        
        var inpText = Int(inputOL.text!)
        
        let randomGood = goodMovies.randomElement()!
        let randomBad = badMovies.randomElement()!
        if inpText! > 3{
            outputOL.text = "\(randomGood)!👍"
            imageOL.image = UIImage(named: "Good.jpg")
        }
        else{
            outputOL.text = "\(randomBad)!👎"
            imageOL.image = UIImage(named: "Bad.png")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

